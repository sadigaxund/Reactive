package Tools;

public class Nums {

    public static int toInt(double a) {
	return (int) a;
    }

    public static double toInt(int a) {
	return (double) a;
    }
    

}
